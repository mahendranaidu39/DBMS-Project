-- Hospital Management System
-- Combined MySQL script
-- Run in MySQL Workbench or the MySQL command-line client.
-- Rerunning this script drops and recreates the tables.

CREATE DATABASE IF NOT EXISTS hospital_management_system;
USE hospital_management_system;

-- Drop existing tables in child-to-parent order
DROP TABLE IF EXISTS Billing;
DROP TABLE IF EXISTS Medical_Record;
DROP TABLE IF EXISTS Prescription_Item;
DROP TABLE IF EXISTS Prescription;
DROP TABLE IF EXISTS Appointment;
DROP TABLE IF EXISTS Medicine;
DROP TABLE IF EXISTS Patient;
DROP TABLE IF EXISTS Doctor;
DROP TABLE IF EXISTS Department;
DROP TABLE IF EXISTS Users;

-- 1. Department
CREATE TABLE Department (
    Department_ID INT PRIMARY KEY,
    Department_Name VARCHAR(50) NOT NULL UNIQUE,
    Location VARCHAR(50),
    In_Charge VARCHAR(50),
    Contact VARCHAR(15)
);

-- 2. Doctor
CREATE TABLE Doctor (
    Doctor_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Specialization VARCHAR(50),
    Contact VARCHAR(15),
    Email VARCHAR(50) UNIQUE,
    Department_ID INT,
    Consultation_Fee DECIMAL(8,2) CHECK (Consultation_Fee >= 0),
    Availability VARCHAR(40),
    FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)
        ON UPDATE CASCADE ON DELETE SET NULL
);

-- 3. Patient
CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M', 'F', 'O')),
    Date_Of_Birth DATE,
    Address VARCHAR(100),
    Contact VARCHAR(15),
    Blood_Group VARCHAR(3)
        CHECK (Blood_Group IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
    Medical_History VARCHAR(200)
);

-- 4. Appointment
CREATE TABLE Appointment (
    Appointment_ID INT PRIMARY KEY,
    Patient_ID INT NOT NULL,
    Doctor_ID INT NOT NULL,
    Appointment_Date DATE NOT NULL,
    Appointment_Time TIME NOT NULL,
    Status VARCHAR(10) NOT NULL DEFAULT 'Scheduled'
        CHECK (Status IN ('Scheduled', 'Completed', 'Cancelled')),
    Remarks VARCHAR(100),
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE (Doctor_ID, Appointment_Date, Appointment_Time)
);

-- 5. Medicine
CREATE TABLE Medicine (
    Medicine_ID INT PRIMARY KEY,
    Medicine_Name VARCHAR(50) NOT NULL,
    Category VARCHAR(30),
    Price DECIMAL(8,2) CHECK (Price >= 0),
    Stock_Quantity INT NOT NULL DEFAULT 0 CHECK (Stock_Quantity >= 0),
    Expiry_Date DATE,
    Manufacturer VARCHAR(50)
);

-- 6. Prescription
CREATE TABLE Prescription (
    Prescription_ID INT PRIMARY KEY,
    Prescription_Date DATE NOT NULL,
    Instructions VARCHAR(200)
);

-- 7. Prescription items
CREATE TABLE Prescription_Item (
    Prescription_ID INT NOT NULL,
    Medicine_ID INT NOT NULL,
    Dosage VARCHAR(40) NOT NULL,
    Duration_Days INT CHECK (Duration_Days > 0),
    Quantity INT CHECK (Quantity > 0),
    PRIMARY KEY (Prescription_ID, Medicine_ID),
    FOREIGN KEY (Prescription_ID) REFERENCES Prescription(Prescription_ID)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (Medicine_ID) REFERENCES Medicine(Medicine_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 8. Medical records
CREATE TABLE Medical_Record (
    Record_ID INT PRIMARY KEY,
    Patient_ID INT NOT NULL,
    Doctor_ID INT NOT NULL,
    Diagnosis VARCHAR(100) NOT NULL,
    Test_Reports VARCHAR(200),
    Treatment_Details VARCHAR(200),
    Prescription_ID INT,
    Record_Date DATE NOT NULL,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (Prescription_ID) REFERENCES Prescription(Prescription_ID)
        ON UPDATE CASCADE ON DELETE SET NULL
);

-- 9. Billing
CREATE TABLE Billing (
    Bill_ID INT PRIMARY KEY,
    Patient_ID INT NOT NULL,
    Appointment_ID INT,
    Total_Amount DECIMAL(10,2) NOT NULL CHECK (Total_Amount >= 0),
    Payment_Status VARCHAR(10) NOT NULL DEFAULT 'Pending'
        CHECK (Payment_Status IN ('Pending', 'Paid', 'Partial')),
    Payment_Mode VARCHAR(10)
        CHECK (Payment_Mode IN ('Cash', 'Card', 'UPI', 'Insurance')),
    Bill_Date DATE NOT NULL,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (Appointment_ID) REFERENCES Appointment(Appointment_ID)
        ON UPDATE CASCADE ON DELETE SET NULL
);

-- 10. User accounts
CREATE TABLE Users (
    User_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Username VARCHAR(30) NOT NULL UNIQUE,
    Password VARCHAR(64) NOT NULL,
    Role VARCHAR(15) NOT NULL CHECK (Role IN ('Admin', 'Receptionist', 'Staff')),
    Contact VARCHAR(15)
);

SELECT 'Schema created successfully' AS Status;

-- Sample data: Departments
INSERT INTO Department
    (Department_ID, Department_Name, Location, In_Charge, Contact)
VALUES
    (1, 'Cardiology', 'Block A, Floor 2', 'Dr. Ramesh Kumar', '0891-2000001'),
    (2, 'Neurology', 'Block A, Floor 3', 'Dr. Sita Devi', '0891-2000002'),
    (3, 'Orthopedics', 'Block B, Floor 1', 'Dr. Kiran Rao', '0891-2000003'),
    (4, 'Pediatrics', 'Block C, Floor 1', 'Dr. Divya Sharma', '0891-2000004'),
    (5, 'General Medicine', 'Block B, Ground', 'Dr. Arjun Mehta', '0891-2000005');

-- Sample data: Doctors
INSERT INTO Doctor
    (Doctor_ID, Name, Specialization, Contact, Email, Department_ID,
     Consultation_Fee, Availability)
VALUES
    (201, 'Dr. Ramesh Kumar', 'Cardiologist', '9800000001',
     'ramesh@hospital.com', 1, 800, 'Mon-Fri 9AM-1PM'),
    (202, 'Dr. Sita Devi', 'Neurologist', '9800000002',
     'sita@hospital.com', 2, 900, 'Mon-Sat 10AM-2PM'),
    (203, 'Dr. Kiran Rao', 'Orthopedic Surgeon', '9800000003',
     'kiran@hospital.com', 3, 700, 'Tue-Sat 11AM-4PM'),
    (204, 'Dr. Divya Sharma', 'Pediatrician', '9800000004',
     'divya@hospital.com', 4, 500, 'Mon-Fri 9AM-5PM'),
    (205, 'Dr. Arjun Mehta', 'General Physician', '9800000005',
     'arjun@hospital.com', 5, 400, 'Mon-Sat 9AM-6PM');

-- Sample data: Patients
INSERT INTO Patient
    (Patient_ID, Name, Gender, Date_Of_Birth, Address, Contact,
     Blood_Group, Medical_History)
VALUES
    (101, 'Anil Verma', 'M', '1985-03-14', 'Visakhapatnam', '9700000001', 'B+', 'Hypertension'),
    (102, 'Priya Nair', 'F', '1992-07-21', 'Vizianagaram', '9700000002', 'O+', NULL),
    (103, 'Rahul Singh', 'M', '1978-11-05', 'Srikakulam', '9700000003', 'A+', 'Type 2 diabetes'),
    (104, 'Meena Iyer', 'F', '2015-01-30', 'Rajahmundry', '9700000004', 'AB+', 'Childhood asthma'),
    (105, 'Suresh Babu', 'M', '1960-09-09', 'Kakinada', '9700000005', 'O-', 'Previous knee surgery'),
    (106, 'Lakshmi Devi', 'F', '1988-05-17', 'Visakhapatnam', '9700000006', 'A-', NULL),
    (107, 'Karthik Reddy', 'M', '1999-12-02', 'Anakapalle', '9700000007', 'B-', NULL);

-- Sample data: Appointments
INSERT INTO Appointment
    (Appointment_ID, Patient_ID, Doctor_ID, Appointment_Date,
     Appointment_Time, Status, Remarks)
VALUES
    (5001, 101, 201, '2026-09-20', '10:00:00', 'Completed', 'BP follow-up'),
    (5002, 102, 205, '2026-09-21', '11:30:00', 'Completed', 'Fever and cold'),
    (5003, 103, 205, '2026-09-22', '09:30:00', 'Completed', 'Sugar monitoring'),
    (5004, 104, 204, '2026-09-25', '10:15:00', 'Completed', 'Wheezing'),
    (5005, 105, 203, '2026-09-29', '12:00:00', 'Scheduled', 'Knee pain'),
    (5006, 101, 201, '2026-10-05', '10:00:00', 'Scheduled', 'Routine ECG'),
    (5007, 106, 202, '2026-10-06', '10:30:00', 'Cancelled', 'Patient unavailable'),
    (5008, 107, 205, '2026-10-07', '09:30:00', 'Scheduled', 'General checkup');

-- Sample data: Medicines
INSERT INTO Medicine
    (Medicine_ID, Medicine_Name, Category, Price, Stock_Quantity, Expiry_Date, Manufacturer)
VALUES
    (701, 'Paracetamol 500mg', 'Analgesic', 2.50, 500, '2027-12-31', 'MediCare Labs'),
    (702, 'Amoxicillin 250mg', 'Antibiotic', 8.00, 200, '2027-06-30', 'HealWell Pharma'),
    (703, 'Atorvastatin 10mg', 'Statin', 12.00, 150, '2028-01-31', 'CardioMeds'),
    (704, 'Metformin 500mg', 'Antidiabetic', 4.50, 300, '2027-09-30', 'GlucoCare'),
    (705, 'Salbutamol Inhaler', 'Bronchodilator', 95.00, 60, '2027-03-31', 'BreathEasy'),
    (706, 'Ibuprofen 400mg', 'NSAID', 3.75, 8, '2026-12-31', 'MediCare Labs');

-- Sample data: Prescriptions
INSERT INTO Prescription (Prescription_ID, Prescription_Date, Instructions)
VALUES
    (801, '2026-09-20', 'Take after meals; low-salt diet'),
    (802, '2026-09-21', 'Rest and plenty of fluids'),
    (803, '2026-09-22', 'Monitor blood sugar daily'),
    (804, '2026-09-25', 'Use inhaler when wheezing');

INSERT INTO Prescription_Item
    (Prescription_ID, Medicine_ID, Dosage, Duration_Days, Quantity)
VALUES
    (801, 703, '1 tablet at night', 30, 30),
    (802, 701, '1 tablet, 3 times daily', 5, 15),
    (802, 702, '1 capsule, 2 times daily', 5, 10),
    (803, 704, '1 tablet, twice daily', 30, 60),
    (804, 705, '2 puffs when needed', 30, 1);

INSERT INTO Medical_Record
    (Record_ID, Patient_ID, Doctor_ID, Diagnosis, Test_Reports,
     Treatment_Details, Prescription_ID, Record_Date)
VALUES
    (601, 101, 201, 'Essential hypertension', 'ECG normal; BP 150/95',
     'Lifestyle change and statin', 801, '2026-09-20'),
    (602, 102, 205, 'Viral fever', 'CBC normal',
     'Symptomatic treatment', 802, '2026-09-21'),
    (603, 103, 205, 'Type 2 diabetes mellitus', 'HbA1c 7.8%',
     'Continue metformin', 803, '2026-09-22'),
    (604, 104, 204, 'Mild asthma', 'Peak flow reduced',
     'Bronchodilator inhaler', 804, '2026-09-25');

INSERT INTO Billing
    (Bill_ID, Patient_ID, Appointment_ID, Total_Amount, Payment_Status,
     Payment_Mode, Bill_Date)
VALUES
    (901, 101, 5001, 1250.00, 'Paid', 'UPI', '2026-09-20'),
    (902, 102, 5002, 520.00, 'Paid', 'Cash', '2026-09-21'),
    (903, 103, 5003, 640.00, 'Partial', 'Card', '2026-09-22'),
    (904, 104, 5004, 595.00, 'Pending', NULL, '2026-09-25'),
    (905, 107, NULL, 300.00, 'Pending', NULL, '2026-09-26');

-- Demo login passwords are stored as SHA-256 hashes.
INSERT INTO Users (User_ID, Name, Username, Password, Role, Contact)
VALUES
    (1, 'System Admin', 'admin', SHA2('admin123', 256), 'Admin', '9000000001'),
    (2, 'Front Desk', 'reception', SHA2('reception123', 256), 'Receptionist', '9000000002'),
    (3, 'Ward Staff', 'staff', SHA2('staff123', 256), 'Staff', '9000000003');

SELECT 'Sample data inserted successfully' AS Status;

-- UPDATE / DELETE demonstrations
UPDATE Patient
SET Contact = '9998887777'
WHERE Patient_ID = 101;

UPDATE Appointment
SET Appointment_Date = '2026-10-08', Appointment_Time = '10:00:00'
WHERE Appointment_ID = 5008;

UPDATE Medicine
SET Stock_Quantity = Stock_Quantity + 100
WHERE Medicine_ID = 701;

UPDATE Billing
SET Payment_Status = 'Paid', Payment_Mode = 'Card'
WHERE Bill_ID = 903;

UPDATE Doctor
SET Availability = 'Mon-Sat 9AM-5PM'
WHERE Department_ID = 4;

DELETE FROM Appointment
WHERE Appointment_ID = 5007;

-- Verify update/delete demonstrations
SELECT * FROM Patient WHERE Patient_ID = 101;
SELECT * FROM Appointment WHERE Appointment_ID = 5008;
SELECT * FROM Medicine WHERE Medicine_ID = 701;
SELECT * FROM Billing WHERE Bill_ID = 903;
SELECT * FROM Appointment WHERE Appointment_ID = 5007;

-- Basic SELECT queries
SELECT * FROM Patient;

SELECT Name, Specialization, Consultation_Fee
FROM Doctor
ORDER BY Consultation_Fee DESC;

SELECT Name, Contact
FROM Patient
WHERE Blood_Group = 'B+'
ORDER BY Name;

SELECT DISTINCT Specialization FROM Doctor;

SELECT Name, Email
FROM Doctor
WHERE Email LIKE '%@hospital.com';

SELECT Name, Medical_History
FROM Patient
WHERE Medical_History IS NOT NULL;

SELECT Bill_ID, Patient_ID, Total_Amount
FROM Billing
WHERE Total_Amount BETWEEN 500 AND 1000;

SELECT Appointment_ID, Appointment_Date, Status
FROM Appointment
WHERE Status IN ('Scheduled', 'Completed')
ORDER BY Appointment_Date;

SELECT Name, Date_Of_Birth
FROM Patient
WHERE Date_Of_Birth >= '1990-01-01';

SELECT Bill_ID, Patient_ID, Total_Amount
FROM Billing
ORDER BY Total_Amount DESC
LIMIT 3;

-- JOIN queries
SELECT Dr.Name AS Doctor, D.Department_Name
FROM Doctor Dr
JOIN Department D ON Dr.Department_ID = D.Department_ID;

SELECT P.Name AS Patient, Dr.Name AS Doctor,
       A.Appointment_Date, A.Appointment_Time, A.Status
FROM Appointment A
JOIN Patient P ON A.Patient_ID = P.Patient_ID
JOIN Doctor Dr ON A.Doctor_ID = Dr.Doctor_ID;

SELECT P.Name AS Patient, M.Diagnosis, Dr.Name AS Doctor, M.Record_Date
FROM Medical_Record M
JOIN Patient P ON M.Patient_ID = P.Patient_ID
JOIN Doctor Dr ON M.Doctor_ID = Dr.Doctor_ID;

SELECT P.Name AS Patient, M.Diagnosis, Med.Medicine_Name,
       PI.Dosage, PI.Duration_Days, PI.Quantity
FROM Medical_Record M
JOIN Patient P ON M.Patient_ID = P.Patient_ID
JOIN Prescription Pr ON M.Prescription_ID = Pr.Prescription_ID
JOIN Prescription_Item PI ON Pr.Prescription_ID = PI.Prescription_ID
JOIN Medicine Med ON PI.Medicine_ID = Med.Medicine_ID;

SELECT P.Patient_ID, P.Name, B.Bill_ID, B.Total_Amount, B.Payment_Status
FROM Patient P
LEFT JOIN Billing B ON P.Patient_ID = B.Patient_ID;

SELECT D.Department_Name, COUNT(Dr.Doctor_ID) AS Doctor_Count
FROM Department D
LEFT JOIN Doctor Dr ON D.Department_ID = Dr.Department_ID
GROUP BY D.Department_Name;

SELECT Dr.Name AS Doctor, D.Department_Name
FROM Doctor Dr
RIGHT JOIN Department D ON Dr.Department_ID = D.Department_ID;

-- MySQL does not support FULL JOIN; emulate with LEFT JOIN + RIGHT JOIN.
SELECT P.Name AS Patient, A.Appointment_ID
FROM Patient P LEFT JOIN Appointment A ON P.Patient_ID = A.Patient_ID
UNION
SELECT P.Name, A.Appointment_ID
FROM Patient P RIGHT JOIN Appointment A ON P.Patient_ID = A.Patient_ID;

SELECT Dr.Name AS Doctor, D.Department_Name
FROM Doctor Dr
CROSS JOIN Department D;

SELECT P.Name AS Patient, Dr.Name AS Doctor, D.Department_Name,
       B.Total_Amount, B.Payment_Status
FROM Billing B
JOIN Patient P ON B.Patient_ID = P.Patient_ID
JOIN Appointment A ON B.Appointment_ID = A.Appointment_ID
JOIN Doctor Dr ON A.Doctor_ID = Dr.Doctor_ID
JOIN Department D ON Dr.Department_ID = D.Department_ID;

-- Aggregate queries
SELECT Department_ID, COUNT(*) AS Total_Doctors
FROM Doctor
GROUP BY Department_ID;

SELECT Doctor_ID, COUNT(*) AS Total_Appointments
FROM Appointment
GROUP BY Doctor_ID;

SELECT D.Department_Name, SUM(B.Total_Amount) AS Total_Revenue
FROM Billing B
JOIN Appointment A ON B.Appointment_ID = A.Appointment_ID
JOIN Doctor Dr ON A.Doctor_ID = Dr.Doctor_ID
JOIN Department D ON Dr.Department_ID = D.Department_ID
GROUP BY D.Department_Name
HAVING SUM(B.Total_Amount) > 500;

SELECT Category, MAX(Price) AS Highest, MIN(Price) AS Lowest
FROM Medicine
GROUP BY Category;

SELECT Category, SUM(Stock_Quantity) AS Total_Stock
FROM Medicine
GROUP BY Category;

SELECT Patient_ID, COUNT(*) AS Visits
FROM Appointment
GROUP BY Patient_ID
HAVING COUNT(*) > 1;

SELECT AVG(Consultation_Fee) AS Average_Fee
FROM Doctor;

SELECT Payment_Status, COUNT(*) AS Bills, SUM(Total_Amount) AS Amount
FROM Billing
GROUP BY Payment_Status;

SELECT Doctor_ID, COUNT(*) AS Appointment_Count
FROM Appointment
GROUP BY Doctor_ID
HAVING COUNT(*) > 1;

-- CRUD demonstration for Patient
INSERT INTO Patient
    (Patient_ID, Name, Gender, Date_Of_Birth, Address, Contact,
     Blood_Group, Medical_History)
VALUES (108, 'R. Aditya', 'M', '2001-05-18', 'Nellore',
        '9700000008', 'O+', NULL);

SELECT * FROM Patient WHERE Patient_ID = 108;
UPDATE Patient SET Address = 'Tirupati' WHERE Patient_ID = 108;
SELECT * FROM Patient WHERE Patient_ID = 108;
DELETE FROM Patient WHERE Patient_ID = 108;
SELECT * FROM Patient WHERE Patient_ID = 108;

-- CRUD demonstration for Medicine
INSERT INTO Medicine
    (Medicine_ID, Medicine_Name, Category, Price, Stock_Quantity,
     Expiry_Date, Manufacturer)
VALUES (707, 'Cetirizine 10mg', 'Antihistamine', 3.00, 120,
        '2027-08-31', 'AllergyFree');

SELECT * FROM Medicine WHERE Medicine_ID = 707;
UPDATE Medicine SET Price = 3.50 WHERE Medicine_ID = 707;
SELECT * FROM Medicine WHERE Medicine_ID = 707;
DELETE FROM Medicine WHERE Medicine_ID = 707;
SELECT * FROM Medicine WHERE Medicine_ID = 707;

-- Views
CREATE OR REPLACE VIEW Appointment_Details_View AS
SELECT A.Appointment_ID, P.Name AS Patient, Dr.Name AS Doctor,
       D.Department_Name, A.Appointment_Date, A.Appointment_Time, A.Status
FROM Appointment A
JOIN Patient P ON A.Patient_ID = P.Patient_ID
JOIN Doctor Dr ON A.Doctor_ID = Dr.Doctor_ID
JOIN Department D ON Dr.Department_ID = D.Department_ID;

CREATE OR REPLACE VIEW Patient_Public_View AS
SELECT Patient_ID, Name, Gender, Date_Of_Birth, Contact, Blood_Group
FROM Patient;

CREATE OR REPLACE VIEW Pending_Bills_View AS
SELECT B.Bill_ID, P.Name AS Patient, P.Contact, B.Total_Amount,
       B.Payment_Status, B.Bill_Date
FROM Billing B
JOIN Patient P ON B.Patient_ID = P.Patient_ID
WHERE B.Payment_Status IN ('Pending', 'Partial');

CREATE OR REPLACE VIEW Medicine_Alert_View AS
SELECT Medicine_ID, Medicine_Name, Stock_Quantity, Expiry_Date,
       CASE WHEN Stock_Quantity < 20 THEN 'Low stock' ELSE 'OK' END AS Stock_Alert,
       CASE WHEN Expiry_Date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY)
            THEN 'Expiring soon' ELSE 'OK' END AS Expiry_Alert
FROM Medicine;

CREATE OR REPLACE VIEW Doctor_Workload_View AS
SELECT Dr.Doctor_ID, Dr.Name, D.Department_Name,
       COUNT(A.Appointment_ID) AS Total_Appointments
FROM Doctor Dr
JOIN Department D ON Dr.Department_ID = D.Department_ID
LEFT JOIN Appointment A
    ON A.Doctor_ID = Dr.Doctor_ID AND A.Status <> 'Cancelled'
GROUP BY Dr.Doctor_ID, Dr.Name, D.Department_Name;

-- Display view results
SELECT * FROM Appointment_Details_View;
SELECT * FROM Appointment_Details_View WHERE Status = 'Scheduled';
SELECT * FROM Patient_Public_View;
SELECT * FROM Pending_Bills_View;
SELECT * FROM Medicine_Alert_View;
SELECT * FROM Medicine_Alert_View
WHERE Stock_Alert <> 'OK' OR Expiry_Alert <> 'OK';
SELECT * FROM Doctor_Workload_View;

-- Validation demonstrations
-- Uncomment and run ONE statement at a time to see its constraint error.
-- These statements are expected to fail.

-- Duplicate primary key:
-- INSERT INTO Department (Department_ID, Department_Name)
-- VALUES (1, 'Duplicate Dept');

-- Appointment referencing a nonexistent patient:
-- INSERT INTO Appointment
--     (Appointment_ID, Patient_ID, Doctor_ID, Appointment_Date, Appointment_Time)
-- VALUES (5999, 999, 201, '2026-11-01', '10:00:00');

-- Duplicate doctor email:
-- INSERT INTO Doctor (Doctor_ID, Name, Email)
-- VALUES (299, 'Dr. Copy Cat', 'ramesh@hospital.com');

-- Negative consultation fee:
-- INSERT INTO Doctor (Doctor_ID, Name, Consultation_Fee)
-- VALUES (298, 'Dr. Bad Fee', -100);

-- NULL in a required column:
-- INSERT INTO Patient (Patient_ID, Name)
-- VALUES (199, NULL);

-- Duplicate doctor appointment time:
-- INSERT INTO Appointment
--     (Appointment_ID, Patient_ID, Doctor_ID, Appointment_Date, Appointment_Time)
-- VALUES (5998, 102, 201, '2026-10-05', '10:00:00');

-- Invalid gender:
-- INSERT INTO Patient (Patient_ID, Name, Gender)
-- VALUES (198, 'Test Patient', 'X');

-- Negative medicine stock:
-- UPDATE Medicine
-- SET Stock_Quantity = Stock_Quantity - 9999
-- WHERE Medicine_ID = 701;

-- Deleting a doctor with appointments:
-- DELETE FROM Doctor WHERE Doctor_ID = 201;

SELECT 'Hospital Management System script completed' AS Status;